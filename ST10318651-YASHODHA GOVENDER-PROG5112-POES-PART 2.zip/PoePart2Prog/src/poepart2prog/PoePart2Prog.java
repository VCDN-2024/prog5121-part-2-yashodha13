/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poepart2prog;

import javax.swing.JOptionPane; //importing joption 
import java.util.ArrayList; // importing arraylist
import java.util.List; //importing lis
import java.util.regex.Pattern; //importing pattern

public class PoePart2Prog {

    private String username; //(geeksforgeeks,2024)
    private String password;//(geeksforgeeks,2024)
    private boolean loggedIn;//(geeksforgeeks,2024)
    private List<Task> tasks;//(geeksforgeeks,2024)

    
    //the code below is initialising logged in and task list
    public PoePart2Prog() {
        loggedIn = false;
        
        
        tasks = new ArrayList<>(); //initialize the list of tasks
    }

    
    
    //the below code checks if the username meets the criteria
    public boolean checkUsername(String username) { //(w3scools,1998)
        
        //the below code checks if the username is less the 5 and has a underscore
        return username.length() <= 5 && username.contains("_");
    }

    
    //the below code checks is the password meets the criteria 
    
    public boolean checkPasswordComplexity(String password) { //(w3scools,1998)
        
        
        return password.length() >= 8 && // checks if the password has 8 characters
                Pattern.compile("[A-Z]").matcher(password).find() &&
                //checks if the password has capital letter
                Pattern.compile("[0-9]").matcher(password).find() &&
                //checks if the password has a number 
                
                Pattern.compile("[^A-Za-z0-9]").matcher(password).find();
    }

    
    //the below code registers the user with their username and password
    public String registerUser(String username, String password) {
        if (checkUsername(username) && checkPasswordComplexity(password)) {
            
            
           
            this.username = username;
            //the above code sets the users name
            
            this.password = password;
            //the above code sets the users password
            
            return "Account successfully created."; //if the username and password meets the criteria it displays a message 
            
        } else {
            return "Invalid username or password."; //if the username or password it displays an error message
        }
    }

    //the below code is used to login the user
    public boolean loginUser(String username, String password) { //(w3scools,1998)
        
        //the below code checks if both usernames and both passwords are the same if it is it sets it at true
        if (this.username != null && this.password != null &&
                this.username.equals(username) && this.password.equals(password)) {
            loggedIn = true;
            return true;
        } else {
            
            //the below code sets the password or username to false if they do not match
            loggedIn = false;
            return false;
        }
    }

    public String returnLoginStatus() { //the below code displays a message saying if the user is logged in or not
        return loggedIn ? "User logged in." : "User not logged in.";
    }

    public void displayWelcomeMessage() {
        System.out.println("Welcome to EasyKanban");
        //the above code displays a welcome message if the user successfully logged in 

    }

    public void addTasks() {
        if (!loggedIn) {
            
            JOptionPane.showMessageDialog(null, "Please login first."); //(geeksforgeeks,2023)
            //the above code will ensure the user is logged in before starting tasks
            return;
        }

        String input = JOptionPane.showInputDialog(null, "Enter the number of tasks you want to add:");//(geeksforgeeks,2023)
        //the above code asks the user for the amount of tasks
        int numTasks = Integer.parseInt(input);
        
        

        for (int i = 0; i < numTasks; i++) { //the code loops and adds specified number of tasks
            String taskName = JOptionPane.showInputDialog(null, "Enter task name:"); //(geeksforgeeks,2023)
            String taskDescription;
            do {
                taskDescription = JOptionPane.showInputDialog(null, "Enter task description:");//(geeksforgeeks,2023)
//aks user for task description
                if (taskDescription.length() > 50) {
                    JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");//(geeksforgeeks,2023)
                }
                //the above code asks the user the describe the task and checks if the decription is less then 50 characters 
                
            } while (taskDescription.length() > 50);

            String developerDetails = JOptionPane.showInputDialog(null, "Enter developer first and last name:");//(geeksforgeeks,2023)
            
           //the above asks for the developers name and surname
           
            String taskDurationStr = JOptionPane.showInputDialog(null, "Enter task duration in hours:");//(geeksforgeeks,2023)
            
            
            int taskDuration = Integer.parseInt(taskDurationStr);

            // Prompt for task status
            String[] options = {"To Do", "Doing", "Done"};
            String taskStatus = (String) JOptionPane.showInputDialog(null, "Select task status:", "Task Status",//(geeksforgeeks,2023)
                    JOptionPane.QUESTION_MESSAGE, null, options, options[0]);//(geeksforgeeks,2023)
// Get task status

            // Create a new task and add it to the task list
            Task task = new Task(taskName, taskDescription, developerDetails, taskDuration, taskStatus);
            tasks.add(task);
      
            // Show confirmation message and task details
            JOptionPane.showMessageDialog(null, "Task successfully captured");//(geeksforgeeks,2023)
            
            
            JOptionPane.showMessageDialog(null, task.printTaskDetails());//(geeksforgeeks,2023)
        }

        // Calculate and display the total hours for all tasks
        int totalHours = Task.returnTotalHours(tasks);
        JOptionPane.showMessageDialog(null, "Total hours for all tasks: " + totalHours + " hours");//(geeksforgeeks,2023)
    }
    
    // Method to run the application
    public void run() {
        displayWelcomeMessage(); // Display welcome message

        // Main loop to display the menu and handle user input
        while (true) {
            // Display menu options and get user's choice
            String choice = JOptionPane.showInputDialog(null, "Menu:\n1. Add tasks\n2. Show report\n3. Quit\nSelect an option:");//(geeksforgeeks,2023)
            switch (choice) {
                case "1":
                    addTasks(); // Call method to add tasks
                    break;
                    
                case "2":
                    JOptionPane.showMessageDialog(null, "Coming Soon"); //(geeksforgeeks,2023)
// Show report message
                    break;
                    
                case "3":
                    JOptionPane.showMessageDialog(null, "Exiting the application.");//(geeksforgeeks,2023)
// Exit message
                    System.exit(0);
                    break;
                    
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option. Please try again.");//(geeksforgeeks,2023)
// Error for invalid option
                    break;
            }
        }
    }
    
    // Main method to run the application
    public static void main(String[] args) {
        PoePart2Prog app = new PoePart2Prog();

        String username = JOptionPane.showInputDialog(null, "Enter username:"); //Get username
        
        String password = JOptionPane.showInputDialog(null, "Enter password:"); //Get password
        
        JOptionPane.showMessageDialog(null, app.registerUser(username, password));//(geeksforgeeks,2023)
// Show registration result

        username = JOptionPane.showInputDialog(null, "Enter username for login:"); //(geeksforgeeks,2023)
// Get username for login
        
        password = JOptionPane.showInputDialog(null, "Enter password for login:"); //(geeksforgeeks,2023)
// Get password for login
        if (app.loginUser(username, password)) {
            JOptionPane.showMessageDialog(null, "Login successful.");//(geeksforgeeks,2023)
// show successful message
        } else {
            JOptionPane.showMessageDialog(null, "Login failed."); //(geeksforgeeks,2023)
//show error message
        }
        System.out.println(app.returnLoginStatus());// Print login status

        // Run the application
        app.run();// Start the application
    }
    
    // Inner Task class to represent a task
// Inner Task class to represent a task

    static class Task {
        private static int taskCount = 0; // Static variable to keep track of task numbers

        private String taskName; //(geeksforgeeks,2024)
        private int taskNumber; //(geeksforgeeks,2024)
        private String taskDescription;//(geeksforgeeks,2024)
        private String developerDetails;//(geeksforgeeks,2024)
        private int taskDuration;//(geeksforgeeks,2024)
        private String taskID;//(geeksforgeeks,2024)
        private String taskStatus;//(geeksforgeeks,2024)

        // Constructor to initialize a task
        public Task(String taskName, String taskDescription, String developerDetails, int taskDuration, String taskStatus) {
            this.taskName = taskName;
            this.taskNumber = taskCount++; // Auto-increment task number
            this.taskDescription = taskDescription;
            this.developerDetails = developerDetails;
            this.taskDuration = taskDuration;
            this.taskStatus = taskStatus;
            this.taskID = createTaskID();  // Generate task ID
        }
        
        // Method to check if the task description is within the required length
        public boolean checkTaskDescription() { //(w3scools,1998)
            return this.taskDescription.length() <= 50;// Check description length
        }
        
        // Method to create a task ID
        public String createTaskID() {
            String taskNamePart = this.taskName.substring(0, 2).toUpperCase();
            String developerNamePart = this.developerDetails.split(" ")[1].substring(this.developerDetails.split(" ")[1].length() - 3).toUpperCase();
            return String.format("%s:%d:%s", taskNamePart, this.taskNumber, developerNamePart);
        }

          // Method to print the task details
        public String printTaskDetails() {
            return String.format(
                     // Format task details as a string
                "Task Status: %s\nDeveloper Details: %s\nTask Number: %d\nTask Name: %s\nTask Description: %s\nTask ID: %s\nTask Duration: %d hours\n",
                this.taskStatus, this.developerDetails, this.taskNumber, this.taskName, this.taskDescription, this.taskID, this.taskDuration
            );
        }
        
        
        // Calculating the total hours for a list of tasks using a static method
        public static int returnTotalHours(List<Task> tasks) {
            int total = 0;
            for (Task task : tasks) {
                total += task.taskDuration;// Sum up the duration of each task
            }
            return total; // Return the total hours
        }
    }
}

/* CODE ATTRIBUTION
Java JOptionPane, geeks for geeks, 2023 accessed from: https://www.geeksforgeeks.org/java-joptionpane/
Java Booleans, w3schools, 1998 accessed from : https://www.w3schools.com/java/java_booleans.asp
Private method, geeks for geeks, 2024 accessed from : https://www.geeksforgeeks.org/how-to-call-private-method-from-another-class-in-java-with-help-of-reflection-api/ 
*/

