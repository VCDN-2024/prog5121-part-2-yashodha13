/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package poepart2prog;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.List;

public class PoePart2ProgTest {

    @Test //(Nalawade,2023)
    public void testCheckUsername_CorrectFormat() { // passed
        PoePart2Prog app = new PoePart2Prog();
        String username = "kyl_1";
        assertTrue("Username should be correctly formatted", app.checkUsername(username));
    }

    @Test //(Nalawade,2023)
    public void testCheckUsername_IncorrectFormat() { // passed 
        PoePart2Prog app = new PoePart2Prog();
        String username = "kyle!!!!!!!";
        assertFalse("Username should be incorrectly formatted", app.checkUsername(username));
    }

    @Test //(Nalawade,2023)
    public void testCheckPasswordComplexity_CorrectFormat() { // passed
        PoePart2Prog app = new PoePart2Prog();
        String password = "Ch&&sec@ke99!";
        assertTrue("Password should meet complexity requirements", app.checkPasswordComplexity(password));
    }

    @Test //(Nalawade,2023)
    public void testCheckPasswordComplexity_IncorrectFormat() { // passed
        PoePart2Prog app = new PoePart2Prog();
        String password = "password";
        assertFalse("Password should not meet complexity requirements", app.checkPasswordComplexity(password));
    }

    @Test //(Nalawade,2023)
    public void testLoginUser_Success() { // passed
        PoePart2Prog app = new PoePart2Prog();
        String username = "kyl_1";
        String password = "Ch&&sec@ke99!";
        app.registerUser(username, password);
        assertTrue("Login should be successful", app.loginUser(username, password));
    }

    @Test //(Nalawade,2023)
    public void testLoginUser_Failure() { // passed
        PoePart2Prog app = new PoePart2Prog();
        String username = "kyl_1";
        String password = "Ch&&sec@ke99!";
        app.registerUser(username, password);
        assertFalse("Login should fail with incorrect credentials", app.loginUser(username, "wrongpassword"));
    }

    @Test //(Nalawade,2023)
    public void testTaskDescription_Success() { // passed
        PoePart2Prog.Task task = new PoePart2Prog.Task("Login Feature", "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        assertTrue("Task description should be within 50 characters", task.checkTaskDescription());
    }

    @Test //(Nalawade,2023)
    public void testTaskDescription_Failure() { // passed
        PoePart2Prog.Task task = new PoePart2Prog.Task("Login Feature", "This description is intentionally made very long to exceed fifty characters and should fail the test", "Robyn Harrison", 8, "To Do");
        assertFalse("Task description should not be more than 50 characters", task.checkTaskDescription());
    }

    @Test //(Nalawade,2023)
    public void testCreateTaskID() { // passed
        PoePart2Prog.Task task = new PoePart2Prog.Task("Login Feature", "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        assertEquals("Task ID should match the expected format", "LO:1:SON", task.createTaskID());
    }

    @Test //(Nalawade,2023)
    public void testReturnTotalHours() { // passed
        List<PoePart2Prog.Task> tasks = new ArrayList<>();
        tasks.add(new PoePart2Prog.Task("Login Feature", "Create Login to authenticate users", "Robyn Harrison", 8, "To Do"));
        tasks.add(new PoePart2Prog.Task("Add Task Feature", "Create Add Task feature to add tasks", "Mike Smith", 10, "Doing"));
        
        assertEquals("Total hours should be the sum of all task durations", 18, PoePart2Prog.Task.returnTotalHours(tasks));
    }

    @Test //(Nalawade,2023)
    public void testReturnTotalHours_MultipleTasks() { // passed
        List<PoePart2Prog.Task> tasks = new ArrayList<>();
        tasks.add(new PoePart2Prog.Task("Task1", "Task description", "Developer One", 10, "To Do"));
        tasks.add(new PoePart2Prog.Task("Task2", "Task description", "Developer Two", 12, "Doing"));
        tasks.add(new PoePart2Prog.Task("Task3", "Task description", "Developer Three", 55, "Done"));
        tasks.add(new PoePart2Prog.Task("Task4", "Task description", "Developer Four", 11, "To Do"));
        tasks.add(new PoePart2Prog.Task("Task5", "Task description", "Developer Five", 1, "Doing"));

        assertEquals("Total hours should be the sum of all task durations", 89, PoePart2Prog.Task.returnTotalHours(tasks));
    }

  
}

/* CODE ATTRIBUTION
Unit Testing, Kunal Nalawade, 2023 accessed from: https://www.freecodecamp.org/news/java-unit-testing/
*/